﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace eRepertuar3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bazaDataSet.Piesni' table. You can move, or remove it, as needed.
            this.piesniTableAdapter.Fill(this.bazaDataSet.Piesni);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.piesniTableAdapter.FillBy(this.bazaDataSet.Piesni);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
        DataTable baza;
        private void button1_Click(object sender, EventArgs e)
        {
            //jodb j = new jodb(@"Data Source=.\SQLEXPRESS;AttachDbFilename=" + "\"" + @"C:\Users\netbook\Documents\Visual Studio 2010\Projects\eRepertuar3\Baza.mdf" + "\"" + @";Integrated Security=True;Connect Timeout=30;User Instance=True");


            jodb j = new jodb(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Baza.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            //string query="select * from Piesni";
            //string query = @"SELECT ID, Tytul, Refren FROM Piesni";
            //string query = @"SELECT Piesni.Tytul, Okresy.Nazwa FROM Piesni INNER JOIN Piesni_Okresy ON Piesni.ID = Piesni_Okresy.Piesni_ID INNER JOIN Okresy ON Piesni_Okresy.Okresy_ID = Okresy.ID";
            //string query = @"SELECT * FROM Piesni INNER JOIN Piesni_Okresy ON Piesni.ID = Piesni_Okresy.Piesni_ID INNER JOIN Okresy ON Piesni_Okresy.Okresy_ID = Okresy.ID";
            //string query = @"SELECT Piesni.*, Okresy.ID AS Okresy_ID, Okresy.Nazwa AS Okresy_Nazwa, Czesci.ID AS Czesci_ID, Czesci.Nazwa AS Czesci_Nazwa, Czesci.Chronologia, Czesci.Podstawowa FROM Piesni INNER JOIN Piesni_Okresy ON Piesni.ID = Piesni_Okresy.Piesni_ID INNER JOIN Czesci ON Piesni_Okresy.Czesci_ID = Czesci.ID INNER JOIN Okresy ON Piesni_Okresy.Okresy_ID = Okresy.ID";
            //string query = @"SELECT Piesni.*, Piesni_Okresy.Okresy_ID, Okresy.Nazwa, Piesni_Okresy.Czesci_ID, Piesni_Okresy.Priorytet, Czesci.Nazwa AS Czesci_Nazwa, Czesci.Chronologia, Czesci.Podstawowa FROM Piesni INNER JOIN Piesni_Okresy ON Piesni.ID = Piesni_Okresy.Piesni_ID INNER JOIN Czesci ON Piesni_Okresy.Czesci_ID = Czesci.ID";
            //string query = @"SELECT Piesni.*, Piesni_Okresy.Okresy_ID, Piesni_Okresy.Czesci_ID, Piesni_Okresy.Priorytet, Okresy.Nazwa, Czesci.Nazwa AS Czesci_Nazwa, Czesci.Chronologia, Czesci.Podstawowa FROM Piesni INNER JOIN Piesni_Okresy ON Piesni.ID = Piesni_Okresy.Piesni_ID INNER JOIN Czesci ON Piesni_Okresy.Czesci_ID = Czesci.ID";
            string query = @"SELECT Piesni.*, Piesni_Okresy.po_ID, Okresy.*, Czesci.* FROM Piesni INNER JOIN Piesni_Okresy ON Piesni.ID = Piesni_Okresy.Piesni_ID INNER JOIN Czesci ON Piesni_Okresy.Czesci_ID = Czesci.c_ID INNER JOIN Okresy ON Piesni_Okresy.Okresy_ID = Okresy.o_ID";

            baza = j.pobierz_dane(query);
            var dt = baza;
            var dv = dataGridView2;

            //o LINQ: http://msdn.microsoft.com/en-us/library/bb397676%28v=vs.110%29.aspx
            //LINQ to DataSet: http://msdn.microsoft.com/en-us/library/bb399401%28v=vs.110%29.aspx
            var czesci = from record in dt.AsEnumerable()
                         group record by record.Field<string>("c_Nazwa") into recordGroup
                         orderby recordGroup.Max(record => record.Field<int>("c_Chronologia"))//równie dobrze mogło być Min()
                         select recordGroup.Key;
                         

            //Typed DataSet: bazaDataSet.Piesni[0].Tytul
            //string msg = "";
            DataTable[] grids = new DataTable[czesci.Count()];
            for(int i=0; i<czesci.Count(); i++)
            {
                grids[i] = new DataTable(czesci.ElementAt(i));
            }
            //MessageBox.Show(msg);
            var grid = grids[0];

            grid.Columns.Add("Skrót", typeof(string));
            grid.Columns.Add("Z", typeof(bool));
            grid.Columns.Add("Tytuł", typeof(string));
            grid.Columns.Add("Priorytet", typeof(int));
            grid.Columns.Add("Ostatnio zagrane", typeof(DateTime));
            grid.Columns.Add("Czas trwania", typeof(DateTime));           

            string[] keys={"1","2","3","4","5","6","7","8","9","0","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
            for (int r = 0; r < dt.Rows.Count; r++)
            {
                DataRow dr = grid.NewRow();                
                if(r<keys.Length) dr["Skrót"] = keys[r];
                dr["Z"] = false;
                dr["Tytuł"] = dt.Rows[r].Field<string>("Tytul");
                grid.Rows.Add(dr);
            }
            dv.DataSource = grid;

        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            var s = (DataGridView)sender;
            DataTable dt = baza;

            if (s.CurrentRow != null)
            {
                
                int selInd = s.CurrentRow.Index;
                if (selInd < dt.Rows.Count)
                {
                    txtRefren.Text = dt.Rows[selInd].Field<string>("Refren");
                    txtTekst.Text = dt.Rows[selInd].Field<string>("Tekst");
                }
                
            }
            
        }

        private void llPlik_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var s = dataGridView2;
            DataTable dt = (DataTable)s.DataSource;
            string defaultFolder = @"C:\Users\netbook\Documents\eRepertuar\";
            if (s.CurrentRow != null)
            {
                int selInd = s.CurrentRow.Index;
                string str = dt.Rows[selInd].Field<string>("Plik");
                if (str != "" && str != null)
                {
                    if (!File.Exists(str)) str = defaultFolder + str;
                    System.Diagnostics.Process.Start(str);
                }
            }
        }
    }
    class jodb
    {
        private SqlConnection polaczenie; //obiekt polaczenia widoczny w calej klasie

        ///
        /// Konstruktor do tworzenia polaczenia za pomoca autoryzacji SQL Server
        ///

        /// uzytkownik /// haslo /// nazwa instancji /// nazwa bazy danych
        public jodb(string user, string pass, string cs)
        {
            polaczenie = new SqlConnection();
            polaczenie.ConnectionString = cs;
            polaczenie.Open();
        }
        ///
        /// Konstruktor do tworzenia polaczenia za pomoca autoryzacji windows
        ///

        /// nazwa instancji /// nazwa bazy danych
        public jodb(string cs)
        {
            polaczenie = new SqlConnection();
            //polaczenie.ConnectionString = @"Data Source="+instance+@";AttachDbFilename="+dbdir+@";Integrated Security=True;Connect Timeout=30;User Instance=True";
            polaczenie.ConnectionString = cs;
            //"Data Source=" + instance + ";" +
            //"Trusted_Connection=yes;" +
            //"database=" + dbdir + "; " +
            //"connection timeout=3";
            polaczenie.Open();
        }
        ///
        /// Metoda do pobierana danych z SQL Server
        ///

        /// zapytanie sqL /// zwraca dane w obiekcie DataTable
        public DataTable pobierz_dane(string q)
        {
            DataTable dt = new DataTable(); // deklaracja i utworzenie instancji obiektu DataTable o nazwie dt
            SqlDataReader dr; // deklaracja obiektu SqlDataReader o nazwie dr
            SqlCommand sqlc; // Deklaracja obiektu SqlCOmmand

            sqlc = new SqlCommand(q);
            // utworzenie instancji SQLCommand ktora ma wykonac zapytanie podane jako parametr
            // w zmiennej q

            sqlc.Connection = this.polaczenie; // wskazanie polaczenia do bazy danych
            dr = sqlc.ExecuteReader(); //wykonanie zapytanie i utworzenie wskaznika dr
            dt.Load(dr); //zaladowanie danych do obiektu DataTAble
            return dt; // zwrocenie danych


        }
    }
}
