﻿namespace eRepertuar3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.bazaDataSet = new eRepertuar3.BazaDataSet();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.ofdBackup = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.llTodo = new System.Windows.Forms.LinkLabel();
            this.txtTODO = new System.Windows.Forms.TextBox();
            this.lblTODO = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Shortcut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Checkboxes = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SongName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PeriodName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastPlayed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumberPlayed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.templateLabel = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.piesni_OkresyDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.piesni_OkresyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.czesciDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.czesciBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.piesniDataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.piesniBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.piesniDataGridView = new System.Windows.Forms.DataGridView();
            this.oIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oNazwaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oKrotkanazwaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oChronologiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDnadokresuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oGlownyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.okresyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnSave = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnChoose = new System.Windows.Forms.Button();
            this.piesniTableAdapter = new eRepertuar3.BazaDataSetTableAdapters.PiesniTableAdapter();
            this.tableAdapterManager = new eRepertuar3.BazaDataSetTableAdapters.TableAdapterManager();
            this.czesciTableAdapter = new eRepertuar3.BazaDataSetTableAdapters.CzesciTableAdapter();
            this.okresyTableAdapter = new eRepertuar3.BazaDataSetTableAdapters.OkresyTableAdapter();
            this.piesni_OkresyTableAdapter = new eRepertuar3.BazaDataSetTableAdapters.Piesni_OkresyTableAdapter();
            this.btnWybrane = new System.Windows.Forms.Button();
            this.btnSaveChosen = new System.Windows.Forms.Button();
            this.btnRestoreChosen = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bazaDataSet)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piesni_OkresyDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesni_OkresyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.czesciDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.czesciBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesniDataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesniBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesniDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.okresyBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(338, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bazaDataSet
            // 
            this.bazaDataSet.DataSetName = "BazaDataSet";
            this.bazaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(716, 3);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(138, 23);
            this.btnExport.TabIndex = 13;
            this.btnExport.Text = "Utwórz kopię zapasową";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnImport
            // 
            this.btnImport.Location = new System.Drawing.Point(860, 3);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(138, 23);
            this.btnImport.TabIndex = 14;
            this.btnImport.Text = "Przywróć kopię zapasową";
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // ofdBackup
            // 
            this.ofdBackup.InitialDirectory = "Kopie zapasowe";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 32);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(986, 403);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.llTodo);
            this.tabPage1.Controls.Add(this.txtTODO);
            this.tabPage1.Controls.Add(this.lblTODO);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(978, 377);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Wybrane okresy";
            // 
            // llTodo
            // 
            this.llTodo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.llTodo.AutoSize = true;
            this.llTodo.Location = new System.Drawing.Point(948, 348);
            this.llTodo.Name = "llTodo";
            this.llTodo.Size = new System.Drawing.Size(24, 13);
            this.llTodo.TabIndex = 9;
            this.llTodo.TabStop = true;
            this.llTodo.Text = "Plik";
            this.llTodo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llTodo_LinkClicked);
            // 
            // txtTODO
            // 
            this.txtTODO.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTODO.Location = new System.Drawing.Point(53, 348);
            this.txtTODO.Name = "txtTODO";
            this.txtTODO.Size = new System.Drawing.Size(889, 20);
            this.txtTODO.TabIndex = 8;
            // 
            // lblTODO
            // 
            this.lblTODO.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTODO.AutoSize = true;
            this.lblTODO.Location = new System.Drawing.Point(6, 351);
            this.lblTODO.Name = "lblTODO";
            this.lblTODO.Size = new System.Drawing.Size(41, 13);
            this.lblTODO.TabIndex = 7;
            this.lblTODO.Text = "TODO:";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(966, 336);
            this.panel2.TabIndex = 5;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 325F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 388F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.templateLabel, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(3247, 279);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.CausesValidation = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Shortcut,
            this.Checkboxes,
            this.SongName,
            this.PeriodName,
            this.Priority,
            this.LastPlayed,
            this.NumberPlayed,
            this.Time});
            this.dataGridView2.Location = new System.Drawing.Point(8, 34);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(319, 271);
            this.dataGridView2.TabIndex = 19;
            this.dataGridView2.Visible = false;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellEndEdit);
            // 
            // Shortcut
            // 
            this.Shortcut.HeaderText = "";
            this.Shortcut.Name = "Shortcut";
            this.Shortcut.ReadOnly = true;
            this.Shortcut.Visible = false;
            this.Shortcut.Width = 20;
            // 
            // Checkboxes
            // 
            this.Checkboxes.HeaderText = "";
            this.Checkboxes.Name = "Checkboxes";
            this.Checkboxes.Width = 20;
            // 
            // SongName
            // 
            this.SongName.HeaderText = "Nazwa";
            this.SongName.Name = "SongName";
            this.SongName.ReadOnly = true;
            this.SongName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // PeriodName
            // 
            this.PeriodName.HeaderText = "Okres";
            this.PeriodName.Name = "PeriodName";
            this.PeriodName.ReadOnly = true;
            this.PeriodName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PeriodName.Width = 50;
            // 
            // Priority
            // 
            this.Priority.HeaderText = "P";
            this.Priority.Name = "Priority";
            this.Priority.ReadOnly = true;
            this.Priority.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Priority.Visible = false;
            this.Priority.Width = 20;
            // 
            // LastPlayed
            // 
            this.LastPlayed.HeaderText = "Ostatnio";
            this.LastPlayed.Name = "LastPlayed";
            this.LastPlayed.ReadOnly = true;
            this.LastPlayed.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LastPlayed.Width = 50;
            // 
            // NumberPlayed
            // 
            this.NumberPlayed.HeaderText = "x";
            this.NumberPlayed.Name = "NumberPlayed";
            this.NumberPlayed.ReadOnly = true;
            this.NumberPlayed.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NumberPlayed.Width = 20;
            // 
            // Time
            // 
            this.Time.HeaderText = "Czas min.";
            this.Time.Name = "Time";
            this.Time.ReadOnly = true;
            this.Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Time.Width = 40;
            // 
            // templateLabel
            // 
            this.templateLabel.AutoSize = true;
            this.templateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.templateLabel.Location = new System.Drawing.Point(8, 5);
            this.templateLabel.Name = "templateLabel";
            this.templateLabel.Size = new System.Drawing.Size(127, 24);
            this.templateLabel.TabIndex = 20;
            this.templateLabel.Text = "templateLabel";
            this.templateLabel.Visible = false;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.piesni_OkresyDataGridView);
            this.tabPage2.Controls.Add(this.czesciDataGridView);
            this.tabPage2.Controls.Add(this.piesniDataGridView1);
            this.tabPage2.Controls.Add(this.piesniDataGridView);
            this.tabPage2.Controls.Add(this.btnSave);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(978, 377);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Podgląd bazy danych";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(673, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Total: od adwentu 2015";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(670, 267);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Kto_umie - kolejność cyfr: LBD; 0 = nie, 1 = nie wiadomo, 2 = tak";
            // 
            // piesni_OkresyDataGridView
            // 
            this.piesni_OkresyDataGridView.AutoGenerateColumns = false;
            this.piesni_OkresyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.piesni_OkresyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51});
            this.piesni_OkresyDataGridView.DataSource = this.piesni_OkresyBindingSource;
            this.piesni_OkresyDataGridView.Location = new System.Drawing.Point(3, 428);
            this.piesni_OkresyDataGridView.Name = "piesni_OkresyDataGridView";
            this.piesni_OkresyDataGridView.Size = new System.Drawing.Size(664, 168);
            this.piesni_OkresyDataGridView.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "po_ID";
            this.dataGridViewTextBoxColumn47.HeaderText = "po_ID";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            this.dataGridViewTextBoxColumn47.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "Piesni_ID";
            this.dataGridViewTextBoxColumn48.HeaderText = "Piesni_ID";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Okresy_ID";
            this.dataGridViewTextBoxColumn49.HeaderText = "Okresy_ID";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Czesci_ID";
            this.dataGridViewTextBoxColumn50.HeaderText = "Czesci_ID";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "Priorytet";
            this.dataGridViewTextBoxColumn51.HeaderText = "Priorytet";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            // 
            // piesni_OkresyBindingSource
            // 
            this.piesni_OkresyBindingSource.DataMember = "Piesni_Okresy";
            this.piesni_OkresyBindingSource.DataSource = this.bazaDataSet;
            // 
            // czesciDataGridView
            // 
            this.czesciDataGridView.AutoGenerateColumns = false;
            this.czesciDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.czesciDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45,
            this.dataGridViewTextBoxColumn46});
            this.czesciDataGridView.DataSource = this.czesciBindingSource;
            this.czesciDataGridView.Location = new System.Drawing.Point(673, 314);
            this.czesciDataGridView.Name = "czesciDataGridView";
            this.czesciDataGridView.Size = new System.Drawing.Size(560, 282);
            this.czesciDataGridView.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.DataPropertyName = "c_ID";
            this.dataGridViewTextBoxColumn43.HeaderText = "c_ID";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "c_Nazwa";
            this.dataGridViewTextBoxColumn44.HeaderText = "c_Nazwa";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.DataPropertyName = "c_Chronologia";
            this.dataGridViewTextBoxColumn45.HeaderText = "c_Chronologia";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.DataPropertyName = "c_Podstawowa";
            this.dataGridViewTextBoxColumn46.HeaderText = "c_Podstawowa";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            // 
            // czesciBindingSource
            // 
            this.czesciBindingSource.DataMember = "Czesci";
            this.czesciBindingSource.DataSource = this.bazaDataSet;
            // 
            // piesniDataGridView1
            // 
            this.piesniDataGridView1.AutoGenerateColumns = false;
            this.piesniDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.piesniDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36});
            this.piesniDataGridView1.DataSource = this.piesniBindingSource;
            this.piesniDataGridView1.Location = new System.Drawing.Point(3, 6);
            this.piesniDataGridView1.Name = "piesniDataGridView1";
            this.piesniDataGridView1.Size = new System.Drawing.Size(1230, 255);
            this.piesniDataGridView1.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 32;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "p_Tytul";
            this.dataGridViewTextBoxColumn22.HeaderText = "p_Tytul";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "p_Trans";
            this.dataGridViewTextBoxColumn37.HeaderText = "p_Trans";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.Width = 50;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "p_Ilosc_zwrotek";
            this.dataGridViewTextBoxColumn24.HeaderText = "L. zwr.";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Width = 50;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "p_Refren";
            this.dataGridViewTextBoxColumn23.HeaderText = "p_Refren";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Width = 70;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "p_Przygrywka_ak";
            this.dataGridViewTextBoxColumn38.HeaderText = "p_Przygrywka_ak";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "p_Przygrywka_dzw";
            this.dataGridViewTextBoxColumn39.HeaderText = "p_Przygrywka_dzw";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "p_Piesn_ak";
            this.dataGridViewTextBoxColumn40.HeaderText = "p_Piesn_ak";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "p_Piesn_dzw";
            this.dataGridViewTextBoxColumn41.HeaderText = "p_Piesn_dzw";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "p_Komentarz";
            this.dataGridViewTextBoxColumn29.HeaderText = "p_Komentarz";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "p_Liczba_zagr_ten_rok";
            this.dataGridViewTextBoxColumn32.HeaderText = "Ten r.";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.Width = 30;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "p_Liczba_zagr_poprz_rok";
            this.dataGridViewTextBoxColumn33.HeaderText = "Poprz. rok";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.Width = 30;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "p_Liczba_zagr_total";
            this.dataGridViewTextBoxColumn34.HeaderText = "Total";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.Width = 40;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "p_Wersja_papierowa";
            this.dataGridViewTextBoxColumn27.HeaderText = "p_Wersja_papierowa";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "p_Tekst";
            this.dataGridViewTextBoxColumn25.HeaderText = "p_Tekst";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "p_Plik";
            this.dataGridViewTextBoxColumn26.HeaderText = "p_Plik";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.DataPropertyName = "p_Zakres";
            this.dataGridViewTextBoxColumn42.HeaderText = "p_Zakres";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "p_Kto_umie_BIN";
            this.dataGridViewTextBoxColumn28.HeaderText = "p_Kto_umie_BIN";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "p_Ostatnio_zagrane";
            this.dataGridViewTextBoxColumn30.HeaderText = "p_Ostatnio_zagrane";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Ostatnio_zagr_Czesci_ID";
            this.dataGridViewTextBoxColumn31.HeaderText = "Ostatnio_zagr_Czesci_ID";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "p_Czas_trwania_min";
            this.dataGridViewTextBoxColumn35.HeaderText = "p_Czas_trwania_min";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "p_Czas_trwania_max";
            this.dataGridViewTextBoxColumn36.HeaderText = "p_Czas_trwania_max";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // piesniBindingSource
            // 
            this.piesniBindingSource.DataMember = "Piesni";
            this.piesniBindingSource.DataSource = this.bazaDataSet;
            // 
            // piesniDataGridView
            // 
            this.piesniDataGridView.AutoGenerateColumns = false;
            this.piesniDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.piesniDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.oIDDataGridViewTextBoxColumn,
            this.oNazwaDataGridViewTextBoxColumn,
            this.oKrotkanazwaDataGridViewTextBoxColumn,
            this.oChronologiaDataGridViewTextBoxColumn,
            this.iDnadokresuDataGridViewTextBoxColumn,
            this.oGlownyDataGridViewTextBoxColumn});
            this.piesniDataGridView.DataSource = this.okresyBindingSource;
            this.piesniDataGridView.Location = new System.Drawing.Point(3, 267);
            this.piesniDataGridView.Name = "piesniDataGridView";
            this.piesniDataGridView.Size = new System.Drawing.Size(658, 155);
            this.piesniDataGridView.TabIndex = 19;
            // 
            // oIDDataGridViewTextBoxColumn
            // 
            this.oIDDataGridViewTextBoxColumn.DataPropertyName = "o_ID";
            this.oIDDataGridViewTextBoxColumn.HeaderText = "o_ID";
            this.oIDDataGridViewTextBoxColumn.Name = "oIDDataGridViewTextBoxColumn";
            this.oIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // oNazwaDataGridViewTextBoxColumn
            // 
            this.oNazwaDataGridViewTextBoxColumn.DataPropertyName = "o_Nazwa";
            this.oNazwaDataGridViewTextBoxColumn.HeaderText = "o_Nazwa";
            this.oNazwaDataGridViewTextBoxColumn.Name = "oNazwaDataGridViewTextBoxColumn";
            // 
            // oKrotkanazwaDataGridViewTextBoxColumn
            // 
            this.oKrotkanazwaDataGridViewTextBoxColumn.DataPropertyName = "o_Krotka_nazwa";
            this.oKrotkanazwaDataGridViewTextBoxColumn.HeaderText = "o_Krotka_nazwa";
            this.oKrotkanazwaDataGridViewTextBoxColumn.Name = "oKrotkanazwaDataGridViewTextBoxColumn";
            // 
            // oChronologiaDataGridViewTextBoxColumn
            // 
            this.oChronologiaDataGridViewTextBoxColumn.DataPropertyName = "o_Chronologia";
            this.oChronologiaDataGridViewTextBoxColumn.HeaderText = "o_Chronologia";
            this.oChronologiaDataGridViewTextBoxColumn.Name = "oChronologiaDataGridViewTextBoxColumn";
            // 
            // iDnadokresuDataGridViewTextBoxColumn
            // 
            this.iDnadokresuDataGridViewTextBoxColumn.DataPropertyName = "ID_nadokresu";
            this.iDnadokresuDataGridViewTextBoxColumn.HeaderText = "ID_nadokresu";
            this.iDnadokresuDataGridViewTextBoxColumn.Name = "iDnadokresuDataGridViewTextBoxColumn";
            // 
            // oGlownyDataGridViewTextBoxColumn
            // 
            this.oGlownyDataGridViewTextBoxColumn.DataPropertyName = "o_Glowny";
            this.oGlownyDataGridViewTextBoxColumn.HeaderText = "o_Glowny";
            this.oGlownyDataGridViewTextBoxColumn.Name = "oGlownyDataGridViewTextBoxColumn";
            // 
            // okresyBindingSource
            // 
            this.okresyBindingSource.DataMember = "Okresy";
            this.okresyBindingSource.DataSource = this.bazaDataSet;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(1158, 602);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "Zapisz dane";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 612);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(320, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Można użyć ujemnych ID z niezapisanych jeszcze pieśni i okresów";
            // 
            // btnChoose
            // 
            this.btnChoose.Location = new System.Drawing.Point(12, 3);
            this.btnChoose.Name = "btnChoose";
            this.btnChoose.Size = new System.Drawing.Size(117, 23);
            this.btnChoose.TabIndex = 17;
            this.btnChoose.Text = "Wybierz okresy";
            this.btnChoose.UseVisualStyleBackColor = true;
            this.btnChoose.Click += new System.EventHandler(this.btnChoose_Click);
            // 
            // piesniTableAdapter
            // 
            this.piesniTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CzesciTableAdapter = this.czesciTableAdapter;
            this.tableAdapterManager.OkresyTableAdapter = this.okresyTableAdapter;
            this.tableAdapterManager.Piesni_OkresyTableAdapter = this.piesni_OkresyTableAdapter;
            this.tableAdapterManager.PiesniTableAdapter = this.piesniTableAdapter;
            this.tableAdapterManager.UpdateOrder = eRepertuar3.BazaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // czesciTableAdapter
            // 
            this.czesciTableAdapter.ClearBeforeFill = true;
            // 
            // okresyTableAdapter
            // 
            this.okresyTableAdapter.ClearBeforeFill = true;
            // 
            // piesni_OkresyTableAdapter
            // 
            this.piesni_OkresyTableAdapter.ClearBeforeFill = true;
            // 
            // btnWybrane
            // 
            this.btnWybrane.Location = new System.Drawing.Point(177, 3);
            this.btnWybrane.Name = "btnWybrane";
            this.btnWybrane.Size = new System.Drawing.Size(107, 23);
            this.btnWybrane.TabIndex = 18;
            this.btnWybrane.Text = "Wybrane pieśni";
            this.btnWybrane.UseVisualStyleBackColor = true;
            this.btnWybrane.Click += new System.EventHandler(this.btnWybrane_Click);
            // 
            // btnSaveChosen
            // 
            this.btnSaveChosen.Location = new System.Drawing.Point(290, 3);
            this.btnSaveChosen.Name = "btnSaveChosen";
            this.btnSaveChosen.Size = new System.Drawing.Size(75, 23);
            this.btnSaveChosen.TabIndex = 19;
            this.btnSaveChosen.Text = "Zapamiętaj";
            this.btnSaveChosen.UseVisualStyleBackColor = true;
            this.btnSaveChosen.Click += new System.EventHandler(this.btnSaveChosen_Click);
            // 
            // btnRestoreChosen
            // 
            this.btnRestoreChosen.Location = new System.Drawing.Point(371, 3);
            this.btnRestoreChosen.Name = "btnRestoreChosen";
            this.btnRestoreChosen.Size = new System.Drawing.Size(75, 23);
            this.btnRestoreChosen.TabIndex = 20;
            this.btnRestoreChosen.Text = "Przywróć";
            this.btnRestoreChosen.UseVisualStyleBackColor = true;
            this.btnRestoreChosen.Click += new System.EventHandler(this.btnRestoreChosen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 447);
            this.Controls.Add(this.btnRestoreChosen);
            this.Controls.Add(this.btnSaveChosen);
            this.Controls.Add(this.btnWybrane);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.btnChoose);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "eRepertuar (od 15.08.2015; keyboard kupiony 22.12.2003)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bazaDataSet)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piesni_OkresyDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesni_OkresyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.czesciDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.czesciBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesniDataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesniBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piesniDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.okresyBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.OpenFileDialog ofdBackup;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnChoose;
        public BazaDataSet bazaDataSet;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label templateLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.BindingSource piesniBindingSource;
        private BazaDataSetTableAdapters.PiesniTableAdapter piesniTableAdapter;
        private BazaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView piesniDataGridView;
        private BazaDataSetTableAdapters.OkresyTableAdapter okresyTableAdapter;
        private System.Windows.Forms.BindingSource okresyBindingSource;
        private System.Windows.Forms.DataGridView piesniDataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn oIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oNazwaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oKrotkanazwaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oChronologiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDnadokresuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oGlownyDataGridViewTextBoxColumn;
        private BazaDataSetTableAdapters.CzesciTableAdapter czesciTableAdapter;
        private System.Windows.Forms.BindingSource czesciBindingSource;
        private System.Windows.Forms.DataGridView czesciDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private BazaDataSetTableAdapters.Piesni_OkresyTableAdapter piesni_OkresyTableAdapter;
        private System.Windows.Forms.BindingSource piesni_OkresyBindingSource;
        private System.Windows.Forms.DataGridView piesni_OkresyDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.TextBox txtTODO;
        private System.Windows.Forms.Label lblTODO;
        private System.Windows.Forms.Button btnWybrane;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSaveChosen;
        private System.Windows.Forms.Button btnRestoreChosen;
        private System.Windows.Forms.DataGridViewTextBoxColumn Shortcut;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Checkboxes;
        private System.Windows.Forms.DataGridViewTextBoxColumn SongName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PeriodName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priority;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastPlayed;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumberPlayed;
        private System.Windows.Forms.DataGridViewTextBoxColumn Time;
        private System.Windows.Forms.LinkLabel llTodo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;


    }
}

